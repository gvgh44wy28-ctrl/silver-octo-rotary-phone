# DeckForge Pro

GitHub Pages-ready single-file web app for deck planning, estimating, plan modeling, saved estimates, installer printouts, and PDF/print estimate output.

## Deploy on GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html` and `.nojekyll` to the root of the repository.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/root`, then click **Save**.
6. Open the Pages URL GitHub gives you.

## Notes

- This is a static app: no backend, no database, and no build step.
- Saved estimates use the browser/device `localStorage`.
- PDF saving uses the browser print/save PDF flow, which works best from Safari/Chrome after the page is hosted.
- Project photos are stored in the active browser session and included in generated estimate printouts.

## Files

- `index.html` — the full DeckForge Pro app.
- `.nojekyll` — prevents GitHub Pages from processing the site with Jekyll.
